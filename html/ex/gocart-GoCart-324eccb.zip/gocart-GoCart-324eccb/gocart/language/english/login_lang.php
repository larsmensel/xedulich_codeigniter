<?php
/******************************************
US English
Admin login Language
******************************************/

$lang['error_authentication_failed'] = 'Authentication Failed!';
$lang['message_logged_out'] = 'You have been logged out.';
$lang['gocart_login'] = 'GoCart Login';
$lang['login'] = 'Login';
$lang['password'] = 'Password';
$lang['email'] = 'Email';
$lang['username'] = 'Username';
$lang['stay_logged_in'] = 'Keep me logged in';